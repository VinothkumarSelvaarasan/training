package ComponentConfig.ComponentConfig.Repository;

import ComponentConfig.ComponentConfig.Model.CartProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CartRepositories extends JpaRepository<CartProduct,Integer> {


    List<CartProduct> findByproductName(String ProductName );
}
