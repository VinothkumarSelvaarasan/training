package ComponentConfig.ComponentConfig.Model;

import lombok.*;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="Customer_Data")
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="customer_id")
    private int customerId;

    @Column(name="customer_registerNumber")
    private String registerNumber;

    @Column(name="customer_name")
    private String customerName;

    @Column(name="mobile_number")
    private long mobileNumber;

    @Column(name="emailid")
    private String emailId;

    @OneToMany(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    @JoinColumn(name="customer_id",referencedColumnName ="customer_id" )
  /*  @JoinTable(name="CUSTOMER_CART",
               joinColumns = {
                    @JoinColumn(name="cid",referencedColumnName = "customer_id")
               },

                inverseJoinColumns={
                    @JoinColumn(name = "cartid",referencedColumnName = "product_id")
                })*/
    private List<CartProduct> cartProductList;







}
