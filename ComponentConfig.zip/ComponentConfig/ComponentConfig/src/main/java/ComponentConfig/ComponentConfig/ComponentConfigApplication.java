package ComponentConfig.ComponentConfig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComponentConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComponentConfigApplication.class, args);
	}

}
