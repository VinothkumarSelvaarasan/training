package ComponentConfig.ComponentConfig.Controllers;

import ComponentConfig.ComponentConfig.Model.Customer;
import ComponentConfig.ComponentConfig.ServicesPackage.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/customerDetails")
public class CustomerController {
    @Autowired
    CustomerService customerService;

    @PostMapping("/addCustomer")
    public Customer saveData(@RequestBody Customer customer)
    {
        return customerService.saveCustomer(customer);
    }
    @GetMapping("/reteriveData/{customerId}")
    public Optional<Customer> findStudent(@PathVariable (value="customerId") int customerId)
    {
        return customerService.findCustomerById(customerId);
    }
    @GetMapping("/reteriveAll")
    public List<Customer> findAllStudents()
    {
        return customerService.findCustomer();
    }
}
