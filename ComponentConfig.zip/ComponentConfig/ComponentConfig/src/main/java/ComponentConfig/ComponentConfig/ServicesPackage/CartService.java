package ComponentConfig.ComponentConfig.ServicesPackage;

import ComponentConfig.ComponentConfig.Repository.CartRepositories;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CartService {
    @Autowired
    CartRepositories cartRepositories;

}
