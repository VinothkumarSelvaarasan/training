package ComponentConfig.ComponentConfig.ServicesPackage;

import ComponentConfig.ComponentConfig.Model.Customer;
import ComponentConfig.ComponentConfig.Repository.CartRepositories;
import ComponentConfig.ComponentConfig.Repository.CustomerRepositories;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepositories customerRepositories;

    @Autowired
    private CartRepositories cartRepositories;

    public CustomerService(CustomerRepositories customerRepositories,
                           CartRepositories cartRepositories) {
        this.customerRepositories = customerRepositories;
        this.cartRepositories = cartRepositories;
    }


    public Customer saveCustomer(Customer customer)
    {
       return customerRepositories.save(customer);
    }

    public List<Customer> findCustomer()
    {
        return customerRepositories.findAll();
    }

    public Optional<Customer> findCustomerById(int customerId)
    {
        return customerRepositories.findById(customerId);
    }

}
